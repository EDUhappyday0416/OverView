#!/bin/sh
cd src/
npm install