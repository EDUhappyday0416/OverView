// import { request } from "../utils/service"


export function getLoginCodeApi() {
    // return request<Login.LoginCodeResponseData>({
    //     url: "login/code",
    //     method: "get"
    // })
}