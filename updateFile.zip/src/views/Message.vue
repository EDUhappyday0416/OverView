<template>
  <div class="card">
    <div class="card__wrapper" >
      <div class="card__user reverse">
        <div class="card__user__message left">早啊早啊早啊</div>
        <div class="card__user__avatar">
          <img
            loading="lazy"
            src="https://images.unsplash.com/photo-1587080266227-677cc2a4e76e?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&amp;ixlib=rb-1.2.1&amp;auto=format&amp;fit=crop&amp;w=934&amp;q=80"
            alt="profile-pic"
          />
        </div>
      </div>
      <div class="card__user reverse">
        <div class="card__user__message left">吃了嗎</div>
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1587080266227-677cc2a4e76e?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&amp;ixlib=rb-1.2.1&amp;auto=format&amp;fit=crop&amp;w=934&amp;q=80"
            alt="profile-pic"
          />
        </div>
      </div>
      <div class="card__user">
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1566465559199-50c6d9c81631?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=934&q=80"
            alt="profile-pic"
          />
        </div>
        <div class="card__user__message right">
          安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎
        </div>
      </div>
      <div class="card__user">
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1566465559199-50c6d9c81631?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=934&q=80"
            alt="profile-pic"
          />
        </div>
        <div class="card__user__message right">
          安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎
        </div>
      </div>
      <div class="card__user">
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1566465559199-50c6d9c81631?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=934&q=80"
            alt="profile-pic"
          />
        </div>
        <div class="card__user__message right">
          安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎
        </div>
      </div>
      <div class="card__user">
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1566465559199-50c6d9c81631?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=934&q=80"
            alt="profile-pic"
          />
        </div>
        <div class="card__user__message right">
          安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎
        </div>
      </div>
      <div class="card__user reverse">
        <div class="card__user__message left">吃了嗎</div>
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1587080266227-677cc2a4e76e?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&amp;ixlib=rb-1.2.1&amp;auto=format&amp;fit=crop&amp;w=934&amp;q=80"
            alt="profile-pic"
          />
        </div>
      </div>
      <div class="card__user reverse">
        <div class="card__user__message left">吃了嗎</div>
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1587080266227-677cc2a4e76e?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&amp;ixlib=rb-1.2.1&amp;auto=format&amp;fit=crop&amp;w=934&amp;q=80"
            alt="profile-pic"
          />
        </div>
      </div>
      <div class="card__user reverse">
        <div class="card__user__message left">吃了嗎</div>
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1587080266227-677cc2a4e76e?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&amp;ixlib=rb-1.2.1&amp;auto=format&amp;fit=crop&amp;w=934&amp;q=80"
            alt="profile-pic"
          />
        </div>
      </div>
      <div class="card__user">
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1566465559199-50c6d9c81631?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=934&q=80"
            alt="profile-pic"
          />
        </div>
        <div class="card__user__message right">
          安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎
        </div>
      </div>
      <div class="card__user">
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1566465559199-50c6d9c81631?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=934&q=80"
            alt="profile-pic"
          />
        </div>
        <div class="card__user__message right">
          安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎
        </div>
      </div>
      <div class="card__user">
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1566465559199-50c6d9c81631?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=934&q=80"
            alt="profile-pic"
          />
        </div>
        <div class="card__user__message right">
          安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎
        </div>
      </div>
      <div class="card__user">
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1566465559199-50c6d9c81631?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=934&q=80"
            alt="profile-pic"
          />
        </div>
        <div class="card__user__message right">
          安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎
        </div>
      </div>
      <div class="card__user">
        <div class="card__user__avatar">
          <img
          loading="lazy"
            src="https://images.unsplash.com/photo-1566465559199-50c6d9c81631?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=934&q=80"
            alt="profile-pic"
          />
        </div>
        <div class="card__user__message right">
          安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎安安你吃飯了嗎
        </div>
      </div>
      <template v-for="(item , i) in message" :key="i">
        <div class="card__user" :class="{ reverse : item.user == 'my' }">
          <div class="card__user__message" :class="{ left : item.user == 'my' }">
            {{ item.message }}
          </div>
          <div class="card__user__avatar">
            <img
              loading="lazy"
              src="../assets/ico_account.svg"
              alt="profile-pic"
            />
          </div>
        </div>
      </template>
    </div>
    <div class="card__button">
      <div class="card__button__input">
        <input type="text" v-model="newMessage">
      </div>
      <div>
        <img src="../assets/ico_add.png" @click="send()"/>
      </div>
    </div>
  </div>
</template>
<script setup>
import { ref } from 'vue'
const message = ref([])
const newMessage = ref('')

const send = () => {
  const data = {
    user:'my',
    message: newMessage.value,
    img:'https://images.unsplash.com/photo-1587080266227-677cc2a4e76e?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&amp;ixlib=rb-1.2.1&amp;auto=format&amp;fit=crop&amp;w=934&amp;q=80' 
  }
  message.value.push(data)
  window.scrollTo({
    top: document.body.scrollHeight,
    behavior: 'smooth'
  })
  newMessage.value = ''
}



</script>
<style lang="scss" scoped>
.card {
  height: 94%;
  border-radius: 10px;
  padding: 22px 16px;
  display: flex;
  flex-direction: column;
  transition: 0.2s;
  background-image: linear-gradient(to top, #a8edea 0%, #fed6e3 100%);
  &__wrapper {
    overflow: auto;
    height: 100vh;
  }
  &__user {
    display: flex;
    padding: 10px 5px;
    align-items: center;
    justify-content: start;

    &__message {
      border-radius: 4px;
      padding: 10px;
      font-size: 12px;
      line-height: 16px;
      width: auto;
      color: white;
      max-width: 85%;
      word-break: break-word;
      margin: 0px 10px;
    }

    .left {
      background-color: #ffffff;
      color: black;
    }
    .right {
      background-color: #477eff;
    }


    &__avatar img {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      -o-object-fit: cover;
      object-fit: cover;
      flex-shrink: 0;
    }
  }
  .reverse {
    justify-content: flex-end;
  }



  &__button {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 13px;


    &__input {
      width: 91%;
    }
  }
}
input {
  outline: none;
  display: block;
  background: rgba(0, 0, 0, 0.1);
  width: 100%;
  border: 0;
  border-radius: 4px;
  box-sizing: border-box;
  padding:6px 20px;
  color: rgba(0, 0, 0, 0.6);
  font-family: inherit;
  font-size: inherit;
  font-weight: 500;
  line-height: inherit;
  transition: 0.3s ease;
  font-size: 16px;
}
</style>
