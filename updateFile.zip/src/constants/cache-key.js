const SYSTEM_NAME = "v3-admin-vite";

const CacheKey = {
    TOKEN: `${SYSTEM_NAME}-token-key`,
};

export default CacheKey;
