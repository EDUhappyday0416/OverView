<script setup>
// import { ref, watch } from 'vue'
</script>

<template>
  <div class="row"></div>
</template>
<style lang="scss" scoped>
.row {
  display: flex;
}
</style>
